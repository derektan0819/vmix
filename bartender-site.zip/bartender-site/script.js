/* ==========================================================================
   Mobile Bartender: script.js
   --------------------------------------------------------------------------
   1. SITE_CONFIG   ← ALL page content lives here. Edit this, not the HTML.
   2. Helpers
   3. Rendering (builds the page from SITE_CONFIG)
   4. Interactions (menu, photo strip, the night row, extras, lightbox, reveal)
   5. Booking form (validation → live estimate → WhatsApp message)
   6. Placeholder checker
   7. Start-up
   ========================================================================== */

'use strict';

/* ==========================================================================
   1. SITE_CONFIG
   --------------------------------------------------------------------------
   • Anything in [square brackets] is a PLACEHOLDER: it is highlighted on the
     page and counted in the corner badge until you replace it. Names in
     brackets (e.g. "[Portable bar setup]") are suggestions: keep only what
     you really offer, and remove the brackets.
   • image: "" shows a placeholder block. To use a real photo, put the file in
     the "images" folder next to index.html and write "images/your-file.jpg".
   • Add/remove items in any list. An EMPTY list ([]) hides that section.
   ========================================================================== */
const SITE_CONFIG = {
  brand: {
    name: "[Your Brand Name]",
    role: "Private mobile bartender",
    serviceArea: "[City / Service area]",
  },

  // First screen. The photo strip is made from hero.image, the cocktail photos
  // and the gallery photos below; the hero photo starts lit in the middle.
  hero: {
    headline: "A private bartender for your party",
    lead: "Craft cocktails for house parties, birthdays, weddings and company events in [City / Service area].",
    image: "", // e.g. "images/me-behind-the-bar.jpg" (portrait 4:5)
    imageAlt: "[Describe the photo, e.g. Bartender pouring a cocktail at a party]",
    caption: "[Your name] behind the bar",
  },

  // Proof shown beside the prices. Real facts only. [] hides it.
  highlights: [
    { value: "[Number]+", label: "events served" },
    { value: "[Number]", label: "years behind the bar" },
    { value: "[Licence / training]", label: "[e.g. certified bartender]" },
  ],

  // Packages: price is free text, shown exactly as written, e.g. "From RM 800"
  packages: [
    {
      id: "intimate",
      name: "Intimate Gathering",
      summary: "For small get-togethers at home with close friends.",
      price: "[Price TBD]",
      details: ["Guests: [TBD]", "Service time: [TBD]", "Included: [TBD]"],
    },
    {
      id: "celebration",
      name: "Birthday & Family Party",
      summary: "For birthdays, anniversaries and family celebrations.",
      price: "[Price TBD]",
      details: ["Guests: [TBD]", "Service time: [TBD]", "Included: [TBD]"],
    },
    {
      id: "event",
      name: "Weddings & Corporate Events",
      summary: "For weddings, company parties and larger occasions.",
      price: "[Price TBD]",
      details: ["Guests: [TBD]", "Service time: [TBD]", "Included: [TBD]"],
    },
  ],

  // Extras: listed under the prices AND offered as choices in the booking form.
  addons: [
    { id: "mocktails", name: "[Mocktail menu]", description: "[Short description]", price: "[Price TBD]" },
    { id: "bar", name: "[Portable bar setup]", description: "[Short description]", price: "[Price TBD]" },
    { id: "glassware", name: "[Glassware]", description: "[Short description]", price: "[Price TBD]" },
    { id: "workshop", name: "[Cocktail workshop]", description: "[Short description]", price: "[Price TBD]" },
  ],

  // The drinks. category groups them on the menu; base is the spirit.
  // Photos are shown at 4:5 (portrait), e.g. 1200 × 1500 px.
  cocktails: [
    { name: "[Cocktail name 1]", base: "[Base spirit]", category: "[Signature]", description: "[One line: flavour and mood]", image: "", imageAlt: "" },
    { name: "[Cocktail name 2]", base: "[Base spirit]", category: "[Signature]", description: "[One line: flavour and mood]", image: "", imageAlt: "" },
    { name: "[Cocktail name 3]", base: "[Base spirit]", category: "[Classic]", description: "[One line: flavour and mood]", image: "", imageAlt: "" },
    { name: "[Cocktail name 4]", base: "[Base spirit]", category: "[Classic]", description: "[One line: flavour and mood]", image: "", imageAlt: "" },
    { name: "[Cocktail name 5]", base: "[Zero-proof base]", category: "[Mocktail]", description: "[One line: flavour and mood]", image: "", imageAlt: "" },
    { name: "[Cocktail name 6]", base: "[Zero-proof base]", category: "[Mocktail]", description: "[One line: flavour and mood]", image: "", imageAlt: "" },
  ],

  // Party photos, shown large and staggered. Real photos open full-size on tap.
  // caption: one short line under the photo ("" = none).
  gallery: [
    { image: "", alt: "", caption: "" },
    { image: "", alt: "", caption: "" },
    { image: "", alt: "", caption: "" },
    { image: "", alt: "", caption: "" },
    { image: "", alt: "", caption: "" },
    { image: "", alt: "", caption: "" },
  ],

  // How the night goes: a row the visitor drags sideways. Each moment can
  // have its own photo (portrait 4:5).
  night: [
    { title: "You send the date", text: "Fill in the form below. It opens WhatsApp with your details ready to send.", image: "", imageAlt: "" },
    { title: "We plan the drinks", text: "[How you settle the menu with the host]", image: "", imageAlt: "" },
    { title: "The date is yours", text: "[How a booking is confirmed, e.g. deposit]", image: "", imageAlt: "" },
    { title: "The bar goes up", text: "[When you arrive and how long set-up takes]", image: "", imageAlt: "" },
    { title: "First pour", text: "[What guests get first, e.g. a welcome drink]", image: "", imageAlt: "" },
    { title: "Last call", text: "[How the night ends, e.g. pack-down and clean-up]", image: "", imageAlt: "" },
  ],

  // Real client reviews only (ask permission first). [] hides the section.
  // The first one is shown large.
  testimonials: [
    { quote: "[Paste a real client review]", name: "[Client name]", event: "[Event type, month year]" },
    { quote: "[Paste a real client review]", name: "[Client name]", event: "[Event type, month year]" },
    { quote: "[Paste a real client review]", name: "[Client name]", event: "[Event type, month year]" },
  ],

  faq: [
    { question: "Do you bring the alcohol, or do I buy it?", answer: "[Answer TBD]" },
    { question: "How far ahead should I book?", answer: "[Answer TBD]" },
    { question: "Which areas do you cover?", answer: "[Answer TBD, including any travel fee]" },
    { question: "What do I need at the venue?", answer: "[Answer TBD, e.g. table, ice, power point]" },
    { question: "Can you make alcohol-free drinks?", answer: "[Answer TBD]" },
    { question: "How do I confirm my booking?", answer: "[Answer TBD, e.g. deposit amount and payment method]" },
  ],

  // The last photograph: the footer is set on it, full width.
  footer: {
    image: "", // e.g. "images/last-call.jpg" (landscape, interest in the middle band)
    imageAlt: "",
  },

  contact: {
    // WhatsApp: country code + number, digits only (no "+", spaces or dashes).
    // e.g. Malaysia 012-345 6789 → "60123456789"
    whatsapp: "[WhatsApp number]",
    whatsappDisplay: "", // optional nicer format, e.g. "+60 12-345 6789"
    email: "[Email address]", // set to "" to hide
  },

  // url: full link, e.g. "https://instagram.com/your.handle". Delete a line to remove it.
  socials: [
    { name: "Instagram", handle: "[@your.handle]", url: "" },
    { name: "TikTok", handle: "[@your.handle]", url: "" },
  ],

  booking: {
    // Keep "Other" in the list: choosing it shows a free-text field.
    eventTypes: ["House party", "Birthday", "Family gathering", "Wedding", "Corporate event", "Other"],
    hoursOptions: [2, 3, 4, 5, 6],
    // First and last lines of the WhatsApp message. {brand} = brand.name
    greeting: "Hi {brand}! I'd like to check your availability for an event.",
    signoff: "Sent from your website booking form.",
    // The live drinks estimate on the ticket. Set to null to hide it.
    estimate: { firstHour: 2, perHourAfter: 1, assumedHours: 4 },
  },

  // Section headings. nav: label in the top menu ("" = not in the menu).
  sections: {
    prices: { nav: "Prices", title: "Prices" },
    menu: { nav: "Drinks", title: "On the menu" },
    gallery: { nav: "", title: "Behind the bar" },
    night: { nav: "The night", title: "How the night goes" },
    reviews: { nav: "", title: "What hosts say" },
    faq: { nav: "Questions", title: "Questions" },
    booking: {
      nav: "",
      title: "Book your night",
      intro: "Send the details and your enquiry opens in WhatsApp, ready to send.",
      note: "I usually reply within [reply time].",
    },
  },

  // Button and label text
  ui: {
    bookNow: "Book now",
    seePrices: "See prices",
    menuOpen: "Menu",
    menuClose: "Close",
    packagesGroup: "Packages",
    extrasGroup: "Extras",
    bookPackage: "Book this package",
    addExtra: "Add to my enquiry",
    extraAdded: "Added to my enquiry",
    notSurePackage: "Not sure yet, help me choose",
    hoursNotSure: "Not sure yet",
    estimateLabel: "Your night, roughly",
    estimateEmpty: "Add your guest count to see roughly how many drinks the night pours.",
    faqMore: "Still have a question?",
    faqMoreLink: "Message me on WhatsApp",
    faqMoreFallback: "Send me an enquiry",
    backToTop: "Back to top",
  },

  // Shows a small "N placeholders left" box in the corner until everything is replaced
  showPlaceholderBadge: true,
};

/* ==========================================================================
   2. Helpers
   ========================================================================== */
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

const PLACEHOLDER_TEST = /\[[^\]]*\]/;
const PLACEHOLDER_ALL = /\[[^\]]*\]/g;
const OTHER_EVENT = "Other";
const DESKTOP = "(min-width: 56em)"; // keep in sync with style.css
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

// Section keys in page order → element id
const SECTION_ORDER = ["prices", "menu", "gallery", "night", "reviews", "faq", "booking"];
const SECTION_ID = { prices: "prices", menu: "menu", gallery: "gallery", night: "night", reviews: "reviews", faq: "faq", booking: "book" };

// Safe access to a list in SITE_CONFIG (missing = empty)
const list = (key) => (Array.isArray(SITE_CONFIG[key]) ? SITE_CONFIG[key] : []);

function escapeHTML(value) {
  const map = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value ?? "").replace(/[&<>"']/g, (ch) => map[ch]);
}

// Escape text for HTML and wrap every [placeholder] in a highlighted span
function t(value) {
  return escapeHTML(value).replace(PLACEHOLDER_ALL, (match) => `<span class="tbd">${match}</span>`);
}

const hasPlaceholder = (value) => PLACEHOLDER_TEST.test(String(value ?? ""));
const fillBrand = (text) => String(text).replace(/\{brand\}/g, SITE_CONFIG.brand.name);
const packageId = (pkg, index) => pkg.id || `package-${index + 1}`;
const addonId = (addon, index) => addon.id || `extra-${index + 1}`;
const toDigits = (value) => String(value).replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));

// Returns the WhatsApp number as digits, or null if it is missing / still a placeholder
function getWhatsAppNumber() {
  const raw = String(SITE_CONFIG.contact.whatsapp || "");
  if (!raw || hasPlaceholder(raw)) return null;
  const digits = raw.replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15 ? digits : null;
}

const waLink = (number, text) => `https://wa.me/${number}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
const isEmail = (value) => /^[^\s@[\]]+@[^\s@[\]]+\.[^\s@[\]]{2,}$/.test(String(value || ""));
const isLiveUrl = (url) => /^https?:\/\//i.test(url || "") && !hasPlaceholder(url);

// Briefly highlight a form control that a shortcut has just filled in
function flash(el) {
  el.classList.add("is-prefilled");
  window.setTimeout(() => el.classList.remove("is-prefilled"), 2500);
}

// A photo, or a flat placeholder block with its size written on it
function media({ image, alt, size, label, eager = false }) {
  if (image) {
    return `<img src="${escapeHTML(image)}" alt="${escapeHTML(alt || "")}" ${eager ? "" : 'loading="lazy"'} decoding="async">`;
  }
  return `<div class="ph" role="img" aria-label="${escapeHTML(`Photo placeholder: ${label || "photo"}`)}">
      <strong>Photo</strong><span>${escapeHTML(size)}</span></div>`;
}

/* ==========================================================================
   3. Rendering
   ========================================================================== */
function renderHeader() {
  $("#brand-link").innerHTML = t(SITE_CONFIG.brand.name);
  $$('[data-cta="book"]').forEach((link) => {
    link.textContent = SITE_CONFIG.ui.bookNow;
  });
  $("#nav-toggle").textContent = SITE_CONFIG.ui.menuOpen;
}

// Top menu: one link per visible section that has a "nav" label
function renderNav() {
  const { sections } = SITE_CONFIG;
  $("#nav-menu").innerHTML = SECTION_ORDER.filter((key) => sections[key] && sections[key].nav)
    .filter((key) => !document.getElementById(SECTION_ID[key]).hidden)
    .map((key) => `<li><a class="bar__link" href="#${SECTION_ID[key]}">${escapeHTML(sections[key].nav)}</a></li>`)
    .join("");
}

// The strip mixes drinks and party photos, with the hero photo fourth
function stripItems() {
  const { hero } = SITE_CONFIG;
  const drinks = list("cocktails").map((c) => ({
    image: c.image, alt: c.imageAlt || c.name, title: c.name, ratio: "4 / 5", size: "4:5 · 1200 × 1500 px",
  }));
  const ratios = [["3 / 2", "3:2 · 1800 × 1200 px"], ["1 / 1", "1:1 · 1500 × 1500 px"], ["4 / 5", "4:5 · 1200 × 1500 px"]];
  const photos = list("gallery").map((g, i) => ({
    image: g.image, alt: g.alt || g.caption || "Party photo", title: g.caption || "", ratio: ratios[i % 3][0], size: ratios[i % 3][1],
  }));
  const mixed = [];
  for (let i = 0; i < Math.max(drinks.length, photos.length); i += 1) {
    if (drinks[i]) mixed.push(drinks[i]);
    if (photos[i]) mixed.push(photos[i]);
  }
  mixed.splice(Math.min(3, mixed.length), 0, {
    image: hero.image, alt: hero.imageAlt, title: hero.caption, ratio: "4 / 5", size: "4:5 · you behind the bar", isHero: true,
  });
  return mixed;
}

function renderHero() {
  const { hero, ui } = SITE_CONFIG;

  $("#hero-strip").innerHTML = stripItems()
    .map(
      (item) => `
      <figure class="strip__frame${item.isHero ? " is-lit" : ""}" style="--ratio: ${item.ratio}"
              data-title="${escapeHTML(item.title)}"${item.image ? "" : ` data-size="${escapeHTML(item.size)}"`}${item.isHero ? ' data-hero="true"' : ""}>
        ${item.image
          ? media({ image: item.image, alt: item.alt, eager: item.isHero })
          : `<div class="ph" role="img" aria-label="${escapeHTML(`Photo placeholder: ${item.title || "photo"}`)}"></div>`}
      </figure>`
    )
    .join("");

  $("#hero-title").innerHTML = t(hero.headline);
  $("#hero-lead").innerHTML = t(hero.lead);
  $("#hero-actions").innerHTML = `
    <a class="button button--accent" href="#book">${escapeHTML(ui.bookNow)}</a>
    <a class="link" href="#prices">${escapeHTML(ui.seePrices)}</a>`;
}

function renderPrices() {
  const { sections, ui } = SITE_CONFIG;
  $("#prices-title").innerHTML = t(sections.prices.title);

  $("#prices-proof").innerHTML = list("highlights")
    .map((h) => `<li><strong>${t(h.value)}</strong> ${t(h.label)}</li>`)
    .join("");

  const packages = list("packages").map(
    (pkg, i) => `
    <div class="price-item" data-reveal style="--i: ${i}">
      <div class="price-item__row">
        <h4 class="price-item__name">${t(pkg.name)}</h4>
        <span class="price-item__price">${t(pkg.price)}</span>
      </div>
      ${pkg.summary ? `<p class="price-item__desc">${t(pkg.summary)}</p>` : ""}
      ${pkg.details && pkg.details.length ? `<p class="price-item__desc">${pkg.details.map(t).join(" · ")}</p>` : ""}
      <a class="price-item__add" href="#book" data-package="${escapeHTML(packageId(pkg, i))}">${escapeHTML(ui.bookPackage)}<span class="visually-hidden">: ${escapeHTML(pkg.name)}</span></a>
    </div>`
  );

  const extras = list("addons").map(
    (addon, i) => `
    <div class="price-item" data-reveal style="--i: ${i}">
      <div class="price-item__row">
        <h4 class="price-item__name">${t(addon.name)}</h4>
        <span class="price-item__price">${t(addon.price)}</span>
      </div>
      ${addon.description ? `<p class="price-item__desc">${t(addon.description)}</p>` : ""}
      <button class="price-item__add" type="button" aria-pressed="false" data-addon="${escapeHTML(addonId(addon, i))}">
        <span class="add__text">${escapeHTML(ui.addExtra)}</span><span class="visually-hidden">: ${escapeHTML(addon.name)}</span>
      </button>
    </div>`
  );

  const group = (name, items) =>
    items.length ? `<div class="price-group"><h3 class="price-group__name">${escapeHTML(name)}</h3>${items.join("")}</div>` : "";
  $("#price-list").innerHTML = group(ui.packagesGroup, packages) + group(ui.extrasGroup, extras);
}

// The drinks as a line-up: grouped by category, one row per drink
function renderMenu() {
  $("#menu-title").innerHTML = t(SITE_CONFIG.sections.menu.title);
  const groups = [];
  list("cocktails").forEach((drink) => {
    const name = drink.category || "";
    let groupEntry = groups.find((g) => g.name === name);
    if (!groupEntry) groups.push((groupEntry = { name, drinks: [] }));
    groupEntry.drinks.push(drink);
  });

  $("#lineup").innerHTML = groups
    .map(
      (g) => `
      <div class="lineup__group">
        ${g.name ? `<h3 class="lineup__group-name">${t(g.name)}</h3>` : ""}
        ${g.drinks
          .map(
            (d, i) => `
          <div class="lineup__row" data-reveal style="--i: ${i % 4}">
            <span class="lineup__name">${t(d.name)}</span>
            <span class="lineup__detail">
              ${d.base ? `<span class="lineup__base">${t(d.base)}</span>` : "<span></span>"}
              ${d.base && d.description ? '<span class="lineup__sep" aria-hidden="true"> · </span>' : ""}
              ${d.description ? `<span class="lineup__desc">${t(d.description)}</span>` : ""}
            </span>
          </div>`
          )
          .join("")}
      </div>`
    )
    .join("");
}

function renderGallery() {
  $("#gallery-title").innerHTML = t(SITE_CONFIG.sections.gallery.title);
  const sizes = ["3:4 portrait", "5:4", "3:2 landscape", "4:5 portrait"];
  $("#gallery-list").innerHTML = list("gallery")
    .map((photo, i) => {
      const label = photo.alt || photo.caption || `Party photo ${i + 1}`;
      const inner = photo.image
        ? `<button class="gallery__open" type="button" data-gallery-index="${i}" aria-label="${escapeHTML(`Enlarge photo: ${label}`)}">
             ${media({ image: photo.image, alt: "" })}
           </button>`
        : media({ size: sizes[i % 4], label });
      return `
        <li class="gallery__item">
          <div class="gallery__media" data-reveal="wipe">${inner}</div>
          ${photo.caption ? `<p class="gallery__caption">${t(photo.caption)}</p>` : ""}
        </li>`;
    })
    .join("");
}

function renderNight() {
  $("#night-title").innerHTML = t(SITE_CONFIG.sections.night.title);
  $("#night-row").innerHTML = list("night")
    .map(
      (m, i) => `
      <li class="moment" data-reveal style="--i: ${i % 4}">
        <h3 class="moment__title">${t(m.title)}</h3>
        ${m.text ? `<p class="moment__text">${t(m.text)}</p>` : ""}
        <span class="moment__space" aria-hidden="true"></span>
        <div class="moment__photo">${media({ image: m.image, alt: m.imageAlt || m.title, size: "4:5 · 1200 × 1500 px", label: m.title })}</div>
      </li>`
    )
    .join("");
}

function renderReviews() {
  $("#reviews-title").textContent = SITE_CONFIG.sections.reviews.title;
  $("#reviews-list").innerHTML = list("testimonials")
    .slice(0, 3)
    .map(
      (r, i) => `
      <figure class="voice${i === 0 ? " voice--lead" : ""}" data-reveal style="--i: ${i}">
        <blockquote class="voice__quote"><p>“${t(r.quote)}”</p></blockquote>
        <figcaption class="voice__by"><span class="voice__name">${t(r.name)}</span>${r.event ? t(r.event) : ""}</figcaption>
      </figure>`
    )
    .join("");
}

// Questions as a table: the heading leads the left column, every answer open
function renderFaq() {
  const { ui, booking, sections } = SITE_CONFIG;
  const wa = getWhatsAppNumber();
  const more = wa
    ? `<a class="link" href="${escapeHTML(waLink(wa, fillBrand(booking.greeting)))}" target="_blank" rel="noopener">${escapeHTML(ui.faqMoreLink)}</a>`
    : `<a class="link" href="#book">${escapeHTML(ui.faqMoreFallback)}</a>`;

  $("#faq-list").innerHTML =
    `<div class="faq__row faq__row--head" data-reveal><h2 class="faq__q" id="faq-title">${t(sections.faq.title)}</h2></div>` +
    list("faq")
      .map(
        (item) => `
        <div class="faq__row" data-reveal>
          <h3 class="faq__q">${t(item.question)}</h3>
          <p class="faq__a">${t(item.answer)}</p>
        </div>`
      )
      .join("") +
    `<div class="faq__row" data-reveal><p class="faq__more">${escapeHTML(ui.faqMore)} ${more}</p></div>`;
}

function renderBooking() {
  const { sections, booking, ui } = SITE_CONFIG;
  const s = sections.booking;
  $("#booking-title").innerHTML = t(s.title);
  $("#booking-lead").innerHTML = t(s.intro || "");
  $("#booking-note").innerHTML = t(s.note || "");
  $("#booking-note").hidden = !s.note;
  $("#estimate-label").textContent = ui.estimateLabel;
  $("#estimate").hidden = !booking.estimate;

  // Event type: one-tap choices
  const types = booking.eventTypes.includes(OTHER_EVENT) ? booking.eventTypes : [...booking.eventTypes, OTHER_EVENT];
  $("#event-choices").innerHTML = types
    .map(
      (type, i) => `
      <label class="choice">
        <input type="radio" name="eventType" value="${escapeHTML(type)}" id="f-event-type-${i}" aria-describedby="f-event-type-error"${i === 0 ? " required" : ""}>
        <span>${escapeHTML(type)}</span>
      </label>`
    )
    .join("");

  $("#f-hours").innerHTML =
    `<option value="">${escapeHTML(ui.hoursNotSure)}</option>` +
    (booking.hoursOptions || []).map((h) => `<option value="${escapeHTML(h)}">${escapeHTML(h)} hours</option>`).join("");

  $("#f-package").innerHTML =
    `<option value="">${escapeHTML(ui.notSurePackage)}</option>` +
    list("packages")
      .map((pkg, i) => {
        const price = pkg.price && !hasPlaceholder(pkg.price) ? ` · ${pkg.price}` : "";
        return `<option value="${escapeHTML(packageId(pkg, i))}">${escapeHTML(pkg.name + price)}</option>`;
      })
      .join("");

  const addons = list("addons");
  $("#field-addons").hidden = !addons.length;
  $("#addon-checks").innerHTML = addons
    .map(
      (addon, i) => `
      <label class="choice">
        <input type="checkbox" name="addons" value="${escapeHTML(addonId(addon, i))}">
        <span>${t(addon.name)}</span>
      </label>`
    )
    .join("");
}

function renderFooter() {
  const { brand, contact, footer, sections, ui } = SITE_CONFIG;
  const item = (html) => `<li>${html}</li>`;

  $("#footer-photo").innerHTML = media({
    image: footer.image, alt: footer.imageAlt, size: "Last photo · landscape, full width", label: "the footer",
  });

  const links = SECTION_ORDER.filter((key) => sections[key] && sections[key].nav)
    .map((key) => `<a class="footer__item link" href="#${SECTION_ID[key]}">${escapeHTML(sections[key].nav)}</a>`)
    .concat(`<a class="footer__item link" href="#book">${escapeHTML(ui.bookNow)}</a>`);

  const contacts = [];
  const wa = getWhatsAppNumber();
  if (wa) {
    contacts.push(`<a class="footer__item link" href="${waLink(wa)}" target="_blank" rel="noopener">WhatsApp ${escapeHTML(contact.whatsappDisplay || `+${wa}`)}</a>`);
  } else if (contact.whatsapp) {
    const shown = hasPlaceholder(contact.whatsapp) ? contact.whatsapp : "[Check WhatsApp number format]";
    contacts.push(`<span class="footer__item">WhatsApp ${t(shown)}</span>`);
  }
  if (isEmail(contact.email)) {
    contacts.push(`<a class="footer__item link" href="mailto:${escapeHTML(contact.email)}">${escapeHTML(contact.email)}</a>`);
  } else if (contact.email) {
    const shown = hasPlaceholder(contact.email) ? contact.email : "[Check email format]";
    contacts.push(`<span class="footer__item">${t(shown)}</span>`);
  }
  list("socials")
    .filter((s) => s.name || s.handle)
    .forEach((s) => {
      const label = [s.name, s.handle].filter(Boolean).join(" ");
      contacts.push(
        isLiveUrl(s.url)
          ? `<a class="footer__item link" href="${escapeHTML(s.url)}" target="_blank" rel="noopener">${t(label)}</a>`
          : `<span class="footer__item">${t(label)}</span>`
      );
    });

  $("#footer-top").innerHTML = `
    <ul class="footer__links" role="list">${links.map(item).join("")}</ul>
    <ul class="footer__contact" role="list">${contacts.map(item).join("")}</ul>`;
  $("#footer-name").innerHTML = t(brand.name);
  $("#footer-legal").innerHTML = `© ${new Date().getFullYear()} ${t(brand.name)} · ${t(brand.role)}, ${t(brand.serviceArea)} · <a class="link" href="#top">${escapeHTML(ui.backToTop)}</a>`;
}

// Hide sections whose list is empty
function applySectionVisibility() {
  const counts = {
    prices: list("packages").length + list("addons").length,
    menu: list("cocktails").length,
    gallery: list("gallery").length,
    night: list("night").length,
    reviews: list("testimonials").length,
    faq: list("faq").length,
    booking: 1,
  };
  SECTION_ORDER.forEach((key) => {
    document.getElementById(SECTION_ID[key]).hidden = !counts[key];
  });
  $("#prices-proof").hidden = !list("highlights").length;
}

/* ==========================================================================
   4. Interactions
   ========================================================================== */
function setupNavigation() {
  const bar = $("#site-header");
  const toggle = $("#nav-toggle");
  const { ui } = SITE_CONFIG;

  const setOpen = (open) => {
    bar.classList.toggle("is-open", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.textContent = open ? ui.menuClose : ui.menuOpen;
  };

  toggle.addEventListener("click", () => setOpen(!bar.classList.contains("is-open")));
  bar.addEventListener("click", (e) => {
    if (e.target.closest("a")) setOpen(false);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && bar.classList.contains("is-open")) {
      setOpen(false);
      toggle.focus();
    }
  });
  document.addEventListener("click", (e) => {
    if (bar.classList.contains("is-open") && !bar.contains(e.target)) setOpen(false);
  });
  window.matchMedia(DESKTOP).addEventListener("change", (e) => {
    if (e.matches) setOpen(false);
  });
}

// Hero strip: the frame nearest the centre is lit, its title sits under it
function setupStrip() {
  const strip = $("#hero-strip");
  const caption = $("#hero-caption");
  const frames = $$(".strip__frame", strip);
  if (!frames.length) return;
  let userMoved = false;

  const centre = (frame) => {
    strip.scrollLeft = frame.offsetLeft - (strip.clientWidth - frame.offsetWidth) / 2;
  };

  const light = () => {
    const box = strip.getBoundingClientRect();
    const mid = box.left + box.width / 2;
    let lit = frames[0];
    let best = Infinity;
    frames.forEach((frame) => {
      const r = frame.getBoundingClientRect();
      const distance = Math.abs(r.left + r.width / 2 - mid);
      if (distance < best) {
        best = distance;
        lit = frame;
      }
    });
    frames.forEach((frame) => frame.classList.toggle("is-lit", frame === lit));
    const parts = [lit.dataset.title ? t(lit.dataset.title) : "", lit.dataset.size ? `<span class="tbd">Photo ${escapeHTML(lit.dataset.size)}</span>` : ""];
    caption.innerHTML = parts.filter(Boolean).join(" · ");
    const pad = parseFloat(getComputedStyle(caption).paddingLeft) || 0;
    const x = Math.max(0, lit.getBoundingClientRect().left - box.left - pad);
    const room = Math.max(0, box.width - pad * 2 - caption.offsetWidth);
    caption.style.setProperty("--caption-x", `${Math.min(x, room)}px`);
  };

  const hero = frames.find((f) => f.dataset.hero === "true") || frames[0];
  centre(hero);
  light();

  let ticking = false;
  strip.addEventListener(
    "scroll",
    () => {
      userMoved = true;
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        light();
        ticking = false;
      });
    },
    { passive: true }
  );

  // Real photos change frame widths once loaded: re-centre until the visitor drags
  window.addEventListener("load", () => {
    if (!userMoved) centre(hero);
    light();
    userMoved = false;
  });
  window.addEventListener("resize", () => light(), { passive: true });
}

// The night: a native sideways row with a progress bar and two buttons
function setupNightRow() {
  const row = $("#night-row");
  const bar = $("#night-progress");
  if (!row || !row.children.length) return;

  const update = () => {
    const max = row.scrollWidth - row.clientWidth;
    const share = max > 0 ? row.scrollLeft / max : 1;
    const visible = max > 0 ? row.clientWidth / row.scrollWidth : 1;
    bar.style.setProperty("--progress", String(Math.min(1, visible + share * (1 - visible))));
  };
  const step = (direction) => {
    const first = row.children[0];
    const gap = parseFloat(getComputedStyle(row).columnGap) || 16;
    row.scrollBy({ left: direction * (first.offsetWidth + gap), behavior: prefersReducedMotion ? "auto" : "smooth" });
  };

  row.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", update, { passive: true });
  $("#night-prev").addEventListener("click", () => step(-1));
  $("#night-next").addEventListener("click", () => step(1));
  update();
}

// Shortcuts that pre-fill the form: "Book this package"
function setupShortcuts() {
  const packageSelect = $("#f-package");
  document.addEventListener("click", (e) => {
    const pkgLink = e.target.closest("[data-package]");
    if (!pkgLink) return;
    packageSelect.value = pkgLink.dataset.package;
    flash(packageSelect);
  });
}

// Extras: the "Add" buttons beside the prices and the form choices stay in sync
function setupExtras() {
  const { ui } = SITE_CONFIG;
  const boxes = () => $$("#addon-checks input");

  const sync = () => {
    const chosen = new Set(boxes().filter((b) => b.checked).map((b) => b.value));
    $$("[data-addon]").forEach((button) => {
      const on = chosen.has(button.dataset.addon);
      button.setAttribute("aria-pressed", String(on));
      $(".add__text", button).textContent = on ? ui.extraAdded : ui.addExtra;
    });
  };

  document.addEventListener("click", (e) => {
    const button = e.target.closest("[data-addon]");
    if (!button) return;
    const box = boxes().find((b) => b.value === button.dataset.addon);
    if (box) {
      box.checked = !box.checked;
      sync();
    }
  });
  $("#addon-checks").addEventListener("change", sync);
}

// Full-size photo viewer for real gallery photos (native <dialog>)
function setupLightbox() {
  const dialog = $("#lightbox");
  if (!dialog || typeof dialog.showModal !== "function") return;

  const img = $("#lightbox-img");
  const caption = $("#lightbox-caption");
  const photos = list("gallery")
    .map((photo, index) => ({ ...photo, index }))
    .filter((photo) => photo.image);
  let current = 0;

  const show = (position) => {
    current = (position + photos.length) % photos.length;
    const photo = photos[current];
    img.src = photo.image;
    img.alt = photo.alt || photo.caption || "Party photo";
    caption.innerHTML = photo.caption ? t(photo.caption) : "";
    caption.hidden = !photo.caption;
  };

  const many = photos.length > 1;
  $("#lightbox-prev").hidden = !many;
  $("#lightbox-next").hidden = !many;

  document.addEventListener("click", (e) => {
    const trigger = e.target.closest("[data-gallery-index]");
    if (!trigger) return;
    show(photos.findIndex((p) => p.index === Number(trigger.dataset.galleryIndex)));
    dialog.showModal();
    document.documentElement.classList.add("has-dialog");
  });

  dialog.addEventListener("close", () => document.documentElement.classList.remove("has-dialog"));
  dialog.addEventListener("click", (e) => {
    if (e.target === dialog) dialog.close();
  });
  dialog.addEventListener("keydown", (e) => {
    if (!many) return;
    if (e.key === "ArrowRight") show(current + 1);
    if (e.key === "ArrowLeft") show(current - 1);
  });
  $("#lightbox-close").addEventListener("click", () => dialog.close());
  $("#lightbox-prev").addEventListener("click", () => show(current - 1));
  $("#lightbox-next").addEventListener("click", () => show(current + 1));
}

// Floating WhatsApp button: opens a chat, or falls back to the form until a number is set
function setupFloatingWhatsApp() {
  const button = $("#wa-float");
  const wa = getWhatsAppNumber();
  if (wa) {
    button.href = waLink(wa, fillBrand(SITE_CONFIG.booking.greeting));
    button.target = "_blank";
    button.rel = "noopener";
  } else {
    button.href = "#book";
    button.setAttribute("aria-label", "Go to the booking form");
  }
}

// The footer name is fitted to run the full width of the page
function setupFooterName() {
  const el = $("#footer-name");
  const fit = () => {
    el.style.fontSize = "100px";
    const width = el.getBoundingClientRect().width; // the name's own width at 100px
    const room = el.parentElement.clientWidth;
    if (width > 0) el.style.fontSize = `${Math.max(40, Math.min(420, Math.floor((100 * room) / width)))}px`;
  };
  fit();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
  let timer;
  window.addEventListener("resize", () => {
    clearTimeout(timer);
    timer = setTimeout(fit, 120);
  }, { passive: true });
}

// Section entrances: each part rises once as it enters (skipped for reduced motion)
function setupReveal() {
  const items = $$("[data-reveal]");
  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    items.forEach((el) => el.classList.add("is-in"));
    return;
  }
  document.documentElement.classList.add("reveal-ready");
  // A picture that opens with a clip-path wipe counts as invisible to the
  // observer while clipped, so its parent is watched instead.
  const watched = new Map(items.map((el) => [el.dataset.reveal === "wipe" ? el.parentElement : el, el]));
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        watched.get(entry.target).classList.add("is-in");
        observer.unobserve(entry.target);
      });
    },
    { rootMargin: "0px 0px -12% 0px", threshold: 0.1 }
  );
  watched.forEach((el, target) => observer.observe(target));
}

/* ==========================================================================
   5. Booking form
   ========================================================================== */
const FIELDS = {
  name: "#f-name",
  contact: "#f-contact",
  date: "#f-date",
  time: "#f-time",
  guests: "#f-guests",
  hours: "#f-hours",
  venue: "#f-venue",
  eventType: 'input[name="eventType"]', // radio group: first one receives focus
  eventOther: "#f-event-other",
  package: "#f-package",
  notes: "#f-notes",
};

const ERROR_IDS = {
  name: "f-name-error",
  contact: "f-contact-error",
  date: "f-date-error",
  guests: "f-guests-error",
  venue: "f-venue-error",
  eventType: "f-event-type-error",
  eventOther: "f-event-other-error",
};

// Friendly error messages, shown under each field
const ERRORS = {
  name: "Please tell me your name.",
  contactEmpty: "Please add a phone/WhatsApp number or email so I can reply.",
  contactInvalid: "That doesn't look quite right. Please check the number or email.",
  dateEmpty: "Please choose the date of your event.",
  datePast: "That date has already passed. Please pick today or a later date.",
  guestsEmpty: "Roughly how many guests? A best guess is fine.",
  guestsInvalid: "Please enter a whole number, like 25.",
  venue: "Where is the party? Just the area is fine.",
  eventType: "Please choose the type of event.",
  eventOther: "Please describe your event in a few words.",
};

// Today's date as YYYY-MM-DD in the visitor's own time zone
function todayISO() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function formatDate(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function validateContact(value) {
  if (!value) return ERRORS.contactEmpty;
  if (value.startsWith("@")) return value.length > 1 ? "" : ERRORS.contactInvalid; // Instagram handle
  if (value.includes("@")) return isEmail(value) ? "" : ERRORS.contactInvalid; // email
  if (/^[\d\s()+.-]+$/.test(value)) {
    return value.replace(/\D/g, "").length >= 7 ? "" : ERRORS.contactInvalid; // phone
  }
  return value.length >= 2 ? "" : ERRORS.contactInvalid; // anything else, e.g. a handle without "@"
}

// Required fields, in page order. Each returns "" when valid, or the error message.
const VALIDATORS = {
  name: (v) => (v ? "" : ERRORS.name),
  contact: validateContact,
  date: (v) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return ERRORS.dateEmpty;
    return v < todayISO() ? ERRORS.datePast : "";
  },
  guests: (v) => {
    if (!v) return ERRORS.guestsEmpty;
    return /^\d+$/.test(v) && Number(v) >= 1 ? "" : ERRORS.guestsInvalid;
  },
  venue: (v) => (v ? "" : ERRORS.venue),
  eventType: (v) => (v ? "" : ERRORS.eventType),
  eventOther: (v, data) => (data.eventType === OTHER_EVENT && !v ? ERRORS.eventOther : ""),
};

function getFormData() {
  const value = (key) => (($(FIELDS[key]) || {}).value || "").trim();
  const chosenType = $('input[name="eventType"]:checked');
  return {
    name: value("name"),
    contact: value("contact"),
    date: value("date"),
    time: value("time"),
    guests: toDigits(value("guests")), // accepts full-width digits from Chinese keyboards
    hours: value("hours"),
    venue: value("venue"),
    eventType: chosenType ? chosenType.value : "",
    eventOther: value("eventOther"),
    package: value("package"),
    addons: $$("#addon-checks input:checked").map((box) => box.value),
    notes: value("notes"),
  };
}

function setFieldError(key, message) {
  const control = $(FIELDS[key]);
  const field = control.closest(".field");
  const error = document.getElementById(ERROR_IDS[key]);
  field.classList.toggle("field--invalid", Boolean(message));
  const targets = key === "eventType" ? $$(FIELDS.eventType) : [control];
  targets.forEach((el) => {
    if (message) el.setAttribute("aria-invalid", "true");
    else el.removeAttribute("aria-invalid");
  });
  if (error) error.textContent = message;
}

function validateField(key, data = getFormData()) {
  const message = VALIDATORS[key](data[key], data);
  setFieldError(key, message);
  return message;
}

// Validates everything; returns the first invalid control (or null)
function validateForm(data) {
  let firstInvalid = null;
  Object.keys(VALIDATORS).forEach((key) => {
    if (validateField(key, data) && !firstInvalid) firstInvalid = $(FIELDS[key]);
  });
  return firstInvalid;
}

// Live estimate: guests × (first-hour drinks + drinks per extra hour)
function updateEstimate() {
  const cfg = SITE_CONFIG.booking.estimate;
  if (!cfg) return;
  const number = $("#estimate-number");
  const rule = $("#estimate-rule");
  const raw = toDigits($("#f-guests").value.trim());
  const guests = /^\d+$/.test(raw) ? Number(raw) : 0;
  const chosenHours = Number($("#f-hours").value);
  const hours = chosenHours || cfg.assumedHours;

  if (!guests) {
    number.innerHTML = `<span class="is-empty">${escapeHTML(SITE_CONFIG.ui.estimateEmpty)}</span>`;
    rule.textContent = `Rule of thumb: ${cfg.firstHour} drinks per guest in the first hour, then ${cfg.perHourAfter} an hour.`;
    return;
  }
  const drinks = Math.round(guests * (cfg.firstHour + Math.max(0, hours - 1) * cfg.perHourAfter));
  number.textContent = `${drinks.toLocaleString("en-GB")} drinks`;
  rule.textContent =
    `${guests} guests over ${hours} hours${chosenHours ? "" : " (assumed)"}. ` +
    `Rule of thumb: ${cfg.firstHour} drinks per guest in the first hour, then ${cfg.perHourAfter} an hour.`;
}

// The message the visitor sends (WhatsApp understands *bold*)
function buildMessage(data) {
  const { booking } = SITE_CONFIG;
  const pkg = list("packages").find((p, i) => packageId(p, i) === data.package);
  const extras = data.addons.map((id) => {
    const addon = list("addons").find((a, i) => addonId(a, i) === id);
    return addon ? addon.name : id;
  });
  const eventType = data.eventType === OTHER_EVENT ? `Other (${data.eventOther})` : data.eventType;

  const lines = [fillBrand(booking.greeting), "", "*Booking enquiry*"];
  lines.push(`Name: ${data.name}`);
  lines.push(`Contact: ${data.contact}`);
  lines.push(`Date: ${formatDate(data.date)}`);
  if (data.time) lines.push(`Start time: ${data.time}`);
  lines.push(`Guests: ${Number(data.guests)}`);
  if (data.hours) lines.push(`Hours: ${data.hours} hours`);
  lines.push(`Venue: ${data.venue}`);
  lines.push(`Event: ${eventType}`);
  lines.push(`Package: ${pkg ? pkg.name : "Not sure yet"}`);
  if (extras.length) lines.push(`Extras: ${extras.join(", ")}`);
  if (data.notes) lines.push("", "*Notes*", data.notes);
  lines.push("", booking.signoff);
  return lines.join("\n");
}

function showResult(message, whatsappUrl) {
  const panel = $("#booking-result");
  const waButton = $("#result-whatsapp");
  const text = $("#result-text");

  $("#result-message").value = message;
  $("#result-status").textContent = "";

  if (whatsappUrl) {
    waButton.href = whatsappUrl;
    waButton.hidden = false;
    text.textContent =
      "WhatsApp should open with your message filled in, so just tap send. If it didn't open, use the button below, or copy the message and send it another way.";
  } else {
    // Owner hasn't set a number yet: make that obvious, keep Copy as the way forward
    waButton.hidden = true;
    text.innerHTML = t(
      "[WhatsApp number not set up yet: add it in SITE_CONFIG.contact.whatsapp] For now, copy the message below and send it using the contact details at the bottom of the page."
    );
  }

  panel.hidden = false;
  panel.focus({ preventScroll: true });
  panel.scrollIntoView({ behavior: prefersReducedMotion ? "auto" : "smooth", block: "start" });
}

async function copyMessage() {
  const textarea = $("#result-message");
  const status = $("#result-status");
  let copied = false;

  try {
    await navigator.clipboard.writeText(textarea.value);
    copied = true;
  } catch {
    // Fallback for older browsers / non-secure pages
    textarea.focus();
    textarea.select();
    textarea.setSelectionRange(0, textarea.value.length);
    try {
      copied = document.execCommand("copy");
    } catch {
      copied = false;
    }
  }

  status.textContent = copied
    ? "Copied. Paste it into WhatsApp, Instagram or an email."
    : "Couldn't copy automatically. The message is selected, so please copy it by hand.";
}

/* --------------------------------------------------------------------------
   SWITCHING TO EMAIL LATER (Formspree or similar)
   --------------------------------------------------------------------------
   1. Create a form at https://formspree.io and copy its endpoint,
      e.g. "https://formspree.io/f/abcdwxyz".
   2. In handleSubmit() below, replace the "WhatsApp" block with:

        fetch("https://formspree.io/f/abcdwxyz", {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ ...data, message }),
        })
          .then((res) => {
            if (!res.ok) throw new Error(res.status);
            // show your own "Thanks, I'll be in touch" message here
          })
          .catch(() => showResult(message, "")); // fall back to Copy

   3. Other services (Web3Forms, EmailJS, Netlify Forms, Google Apps Script)
      work the same way: POST `data` as JSON or FormData to their URL.
   -------------------------------------------------------------------------- */
let hasTriedSubmit = false;

function handleSubmit(event) {
  event.preventDefault();
  hasTriedSubmit = true;

  const data = getFormData();
  const firstInvalid = validateForm(data);
  if (firstInvalid) {
    firstInvalid.focus(); // focus moves to the first problem; its error is read out by screen readers
    return;
  }

  const message = buildMessage(data);

  // --- WhatsApp ---
  const number = getWhatsAppNumber();
  const whatsappUrl = number ? waLink(number, message) : "";
  if (whatsappUrl) {
    // Opened during the submit click, so pop-up blockers allow it
    const win = window.open(whatsappUrl, "_blank");
    if (win) win.opener = null;
  }
  showResult(message, whatsappUrl);
}

function setupBookingForm() {
  const form = $("#booking-form");
  const otherField = $("#field-event-other");

  $(FIELDS.date).min = todayISO(); // date picker greys out past days

  // Show the free-text field only when "Other" is chosen
  $("#event-choices").addEventListener("change", () => {
    const chosen = $('input[name="eventType"]:checked');
    const isOther = Boolean(chosen && chosen.value === OTHER_EVENT);
    otherField.hidden = !isOther;
    if (!isOther) setFieldError("eventOther", "");
    if (hasTriedSubmit) validateField("eventType");
  });

  // Live feedback: check a field when leaving it (if filled in),
  // and re-check as the visitor types once an error is showing
  ["name", "contact", "date", "guests", "venue", "eventOther"].forEach((key) => {
    const input = $(FIELDS[key]);
    input.addEventListener("blur", () => {
      if (input.value.trim() || hasTriedSubmit) validateField(key);
    });
    const recheck = () => {
      if (hasTriedSubmit || input.getAttribute("aria-invalid") === "true") validateField(key);
    };
    input.addEventListener("input", recheck);
    input.addEventListener("change", recheck);
  });

  // The estimate follows guests and hours as they are typed
  $("#f-guests").addEventListener("input", updateEstimate);
  $("#f-hours").addEventListener("change", updateEstimate);
  updateEstimate();

  form.addEventListener("submit", handleSubmit);
  $("#result-copy").addEventListener("click", copyMessage);
}

/* ==========================================================================
   6. Placeholder checker
   --------------------------------------------------------------------------
   Lists everything still marked [ ... ], every missing photo and the SEO
   tags in index.html. Full list: open the corner badge, or the browser
   console. The badge disappears by itself once the list is empty.
   ========================================================================== */
function collectPlaceholders() {
  const found = [];

  (function walk(value, path) {
    if (typeof value === "string") {
      if (hasPlaceholder(value)) found.push(path);
    } else if (Array.isArray(value)) {
      value.forEach((v, i) => walk(v, `${path}[${i}]`));
    } else if (value && typeof value === "object") {
      Object.entries(value).forEach(([k, v]) => walk(v, `${path}.${k}`));
    }
  })(SITE_CONFIG, "SITE_CONFIG");

  if (SITE_CONFIG.contact.whatsapp && !hasPlaceholder(SITE_CONFIG.contact.whatsapp) && !getWhatsAppNumber()) {
    found.push("SITE_CONFIG.contact.whatsapp (wrong format: digits only, with country code)");
  }
  if (!SITE_CONFIG.hero.image) found.push("SITE_CONFIG.hero.image (photo)");
  if (!SITE_CONFIG.footer.image) found.push("SITE_CONFIG.footer.image (photo)");
  ["cocktails", "gallery", "night"].forEach((key) => {
    list(key).forEach((item, i) => {
      if (!item.image) found.push(`SITE_CONFIG.${key}[${i}].image (photo)`);
    });
  });

  if (hasPlaceholder(document.title)) found.push("index.html <title>");
  $$("head meta[content]").forEach((meta) => {
    if (hasPlaceholder(meta.content)) {
      found.push(`index.html <meta ${meta.getAttribute("property") || meta.getAttribute("name")}>`);
    }
  });

  return found;
}

function reportPlaceholders() {
  const found = collectPlaceholders();
  if (!found.length) return;

  console.warn(`[Site] ${found.length} placeholders left to replace:\n- ${found.join("\n- ")}`);
  if (!SITE_CONFIG.showPlaceholderBadge) return;

  const badge = document.createElement("div");
  badge.className = "tbd-badge";
  badge.innerHTML = `
    <details>
      <summary>${found.length} placeholder${found.length === 1 ? "" : "s"} left to replace</summary>
      <ol>${found.map((item) => `<li>${escapeHTML(item)}</li>`).join("")}</ol>
    </details>
    <button class="tbd-badge__close" type="button" aria-label="Hide placeholder notice">×</button>`;
  badge.querySelector("button").addEventListener("click", () => badge.remove());
  document.body.appendChild(badge);
}

/* ==========================================================================
   7. Start-up
   ========================================================================== */
function init() {
  renderHeader();
  renderHero();
  renderPrices();
  renderMenu();
  renderGallery();
  renderNight();
  renderReviews();
  renderFaq();
  renderBooking();
  renderFooter();
  applySectionVisibility();
  renderNav();

  setupNavigation();
  setupStrip();
  setupNightRow();
  setupShortcuts();
  setupExtras();
  setupLightbox();
  setupFloatingWhatsApp();
  setupFooterName();
  setupBookingForm();
  setupReveal();
  reportPlaceholders();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
